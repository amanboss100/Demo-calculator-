function appendToDisplay(value) {
    document.getElementById("result").value += value;
}

function clearDisplay() {
    document.getElementById("result").value = "";
}

function deleteLast() {
    let display = document.getElementById("result");
    display.value = display.value.slice(0, -1);
}

function calculate() {
    try {
        document.getElementById("result").value = eval(document.getElementById("result").value);
    } catch {
        document.getElementById("result").value = "Error";
    }
}

